#ifndef SCREEN_H
#define SCREEN_H

void PrintScreen();
void GameOver();

#endif
