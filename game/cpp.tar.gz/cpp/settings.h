#ifndef SETTINGS_H
#define SETTINGS_H

int SetTicker(int);
void SetUp();
void WrapUp();

#endif
